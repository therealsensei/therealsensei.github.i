<!doctype html>
<html class="no-elementor-popup" lang="en-US">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	
	<!-- This site is optimized with the Yoast SEO plugin v15.7 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Page not found - Action Refund</title>
	<meta name="robots" content="noindex, follow" />
	<meta property="og:locale" content="en_US" />
	<meta property="og:title" content="Page not found - Action Refund" />
	<meta property="og:site_name" content="Action Refund" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://actionrefund.com/#website","url":"https://actionrefund.com/","name":"Action Refund","description":"Legit Chargeback Company","potentialAction":[{"@type":"SearchAction","target":"https://actionrefund.com/?s={search_term_string}","query-input":"required name=search_term_string"}],"inLanguage":"en-US"}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='//code.jquery.com' />
<link rel='dns-prefetch' href='//cdn.jsdelivr.net' />
<link rel='dns-prefetch' href='//widget.trustpilot.com' />
<link rel='dns-prefetch' href='//cdnjs.cloudflare.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Action Refund &raquo; Feed" href="https://actionrefund.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Action Refund &raquo; Comments Feed" href="https://actionrefund.com/comments/feed/" />
		<script>
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/actionrefund.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.4.12"}};
			/*! This file is auto-generated */
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style>
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='https://actionrefund.com/wp-includes/css/dist/block-library/style.min.css?ver=5.4.12' media='all' />
<link rel='stylesheet' id='wpml-legacy-dropdown-0-css'  href='//actionrefund.com/wp-content/plugins/sitepress-multilingual-cms/templates/language-switchers/legacy-dropdown/style.css?ver=1' media='all' />
<link rel='stylesheet' id='wpml-tm-admin-bar-css'  href='https://actionrefund.com/wp-content/plugins/wpml-translation-management/res/css/admin-bar-style.css?ver=2.9.11' media='all' />
<link rel='stylesheet' id='coelix-main-style-css'  href='https://actionrefund.com/wp-content/themes/coelix/dist/main.css?ver=1664539757' media='all' />
<link rel='stylesheet' id='select2-style-css'  href='https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css?ver=5.4.12' media='all' />
<link rel='stylesheet' id='coelix-slick-styles-css'  href='https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.css?ver=5.4.12' media='all' />
<link rel='stylesheet' id='coelix-lazyembed-style-css'  href='https://actionrefund.com/wp-content/themes/coelix/dist/lazyembed.min.css?ver=1664539757' media='all' />
<script src='https://code.jquery.com/jquery-3.5.1.min.js'></script>
<script defer src='https://actionrefund.com/wp-content/plugins/sitepress-multilingual-cms/res/js/jquery.cookie.js?ver=4.3.19'></script>
<script>
var wpml_cookies = {"wp-wpml_current_language":{"value":"en","expires":1,"path":"\/"}};
var wpml_cookies = {"wp-wpml_current_language":{"value":"en","expires":1,"path":"\/"}};
</script>
<script defer src='https://actionrefund.com/wp-content/plugins/sitepress-multilingual-cms/res/js/cookies/language-cookie.js?ver=4.3.19'></script>
<script defer src='//actionrefund.com/wp-content/plugins/sitepress-multilingual-cms/templates/language-switchers/legacy-dropdown/script.js?ver=1'></script>
<link rel='https://api.w.org/' href='https://actionrefund.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://actionrefund.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://actionrefund.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.4.12" />
<meta name="generator" content="WPML ver:4.3.19 stt:1,4,3;" />
<script>

	/* write your JavaScript code here */

</script>
<style>.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><link rel="icon" href="https://actionrefund.com/wp-content/uploads/2022/09/cropped-favicon-diy-32x32.png" sizes="32x32" />
<link rel="icon" href="https://actionrefund.com/wp-content/uploads/2022/09/cropped-favicon-diy-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://actionrefund.com/wp-content/uploads/2022/09/cropped-favicon-diy-180x180.png" />
<meta name="msapplication-TileImage" content="https://actionrefund.com/wp-content/uploads/2022/09/cropped-favicon-diy-270x270.png" />
		<style id="wp-custom-css">
			#menu-item-wpml-ls-9-en,
#menu-item-wpml-ls-9-fr,
#menu-item-wpml-ls-9-de {
	display: block;
	position: relative;
}
.wpml-ls-current-language {
	padding: 0 7px;
}
#menu-item-wpml-ls-9-en .sub-menu,
#menu-item-wpml-ls-9-fr .sub-menu,
#menu-item-wpml-ls-9-de .sub-menu {
	opacity: 0;
	position: absolute;
}
#menu-item-wpml-ls-9-en:hover .sub-menu,
#menu-item-wpml-ls-9-fr:hover .sub-menu,
#menu-item-wpml-ls-9-de:hover .sub-menu {
	opacity: 1;
}
#menu-item-wpml-ls-9-en,
#menu-item-wpml-ls-9-fr,
#menu-item-wpml-ls-9-de {
	display: block;
}


.language-switcher {
	font-size: 18px;
	-webkit-tap-highlight-color: rgba(0, 0, 0, 0);
}
.language-switcher__active img {
	width: 20px;
  height: 20px;
}

.language-switcher:hover .language-switcher__list {
	opacity: 1;
	pointer-events: all;
}

.language-switcher:hover .language-switcher__active::after {
	transform: rotate(135deg) translate3d(0, -2px, 0);
}

.language-switcher__list {
	right: unset;
	display: flex;
  flex-direction: column;
  align-items: center;
	width: 100%;
	padding: 3px;
	padding-right: 7px;
  background: linear-gradient( 
180deg
 ,#516adf,#4760cf);
  border-radius: 5px;
}

.language-switcher__list a img {
	width: 15px;
	height: 15px;
	border-radius: 50%;
}

.language-switcher__list:hover,
.language-switcher__list li:hover,
.language-switcher__list a:hover {
	opacity: 1;
	pointer-events: all;
}
		</style>
		</head>

<body class="error404 hfeed">
<div class="body-background"></div>

<header class="header">
	<div class="wrapper">
		<div class="header__inner">
			<div class="header__burger-menu">
				<div class="line" id="line-1"></div>
				<div class="line" id="line-2"></div>
				<div class="line" id="line-3"></div>
			</div>
			<a class="header__logo" href="https://actionrefund.com"><img src="https://actionrefund.com/wp-content/themes/coelix/assets/images/svg/logo.svg" alt="Action refund logo"></a>
			<ul class="header__nav">
				<li id="menu-item-1592" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-1592"><a href="https://actionrefund.com/">Home</a></li>
<li id="menu-item-1596" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1596"><a href="https://actionrefund.com/about/">About</a></li>
<li id="menu-item-1696" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1696"><a href="https://actionrefund.com/new-action-service/">Service</a></li>
<li id="menu-item-1697" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1697"><a href="https://actionrefund.com/new-action-testimonials/">Testimonials</a></li>
<li id="menu-item-1698" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1698"><a href="https://actionrefund.com/new-action-faq/">FAQ</a></li>
<li id="menu-item-1699" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1699"><a href="https://actionrefund.com/new-action-articles-1/">Latest News</a></li>
<li id="menu-item-1700" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1700"><a href="https://actionrefund.com/new-action-contacts/">Contact us</a></li>
<li id="menu-item-601" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-601"><a href="https://actionrefund.com/payment/">Secure Payment</a></li>
				<li class="menu-item">
					<nav class="header__social">
										<a target="_blank" href="https://www.facebook.com/Action-Refund-LTD-105591984244275/"><img src="https://actionrefund.com/wp-content/uploads/2020/11/facebook.svg" alt="action refund"></a>
										<a target="_blank" href="https://twitter.com/LtdRefund"><img src="https://actionrefund.com/wp-content/uploads/2020/11/twitter.svg" alt="action refund"></a>
										<a target="_blank" href="https://www.instagram.com/actionrefund/?igshid=1vn6oecckogq3"><img src="https://actionrefund.com/wp-content/uploads/2020/12/instagram.svg" alt="action refund"></a>
									</nav>
				</li>
			</ul>
			<nav class="header__social">
								<a target="_blank" href="https://www.facebook.com/Action-Refund-LTD-105591984244275/"><img src="https://actionrefund.com/wp-content/uploads/2020/11/facebook.svg" alt="action refund"></a>
								<a target="_blank" href="https://twitter.com/LtdRefund"><img src="https://actionrefund.com/wp-content/uploads/2020/11/twitter.svg" alt="action refund"></a>
								<a target="_blank" href="https://www.instagram.com/actionrefund/?igshid=1vn6oecckogq3"><img src="https://actionrefund.com/wp-content/uploads/2020/12/instagram.svg" alt="action refund"></a>
							</nav>
			<div class="language-switcher">
    <span class="language-switcher__active">
        <img src="https://actionrefund.com/wp-content/uploads/flags/en.png">
        en    </span>
    <ul class="language-switcher__list">
        
        <li>
            <a class="language-switcher__link" href="https://actionrefund.com/fr/">
                <img src="https://actionrefund.com/wp-content/plugins/sitepress-multilingual-cms/res/flags/fr.png">
                fr            </a>
        </li>
        
        <li>
            <a class="language-switcher__link" href="https://actionrefund.com/de/">
                <img src="https://actionrefund.com/wp-content/plugins/sitepress-multilingual-cms/res/flags/de.png">
                de            </a>
        </li>
            </ul>
</div>
		</div>
	</div>
</header>
	<main id="primary" class="site-main">

		<section class="error-404 not-found">
			<header class="page-header">
				<h1 class="page-title">Oops! That page can&rsquo;t be found.</h1>
			</header><!-- .page-header -->

			<div class="page-content">
				<p>It looks like nothing was found at this location. Maybe try one of the links below or a search?</p>

					<form role="search" method="get" class="search-form" action="https://actionrefund.com/">
				<label>
					<span class="screen-reader-text">Search for:</span>
					<input type="search" class="search-field" placeholder="Search &hellip;" value="" name="s" />
				</label>
				<input type="submit" class="search-submit" value="Search" />
			</form>		<div class="widget widget_recent_entries">		<h2 class="widgettitle">Recent Posts</h2>		<ul>
											<li>
					<a href="https://actionrefund.com/diy-chargeback-is-it-possible-and-how/">DIY Chargeback – Is It Possible And How?</a>
									</li>
											<li>
					<a href="https://actionrefund.com/regulations-are-they-crucial-for-a-business/">Regulations: Are they crucial for a business?</a>
									</li>
											<li>
					<a href="https://actionrefund.com/how-to-spot-a-scam-website/">How to spot a scam website</a>
									</li>
											<li>
					<a href="https://actionrefund.com/how-does-chargeback-work/">How does chargeback work?</a>
									</li>
					</ul>
		</div>
					<div class="widget widget_categories">
						<h2 class="widget-title">Most Used Categories</h2>
						<ul>
								<li class="cat-item cat-item-1"><a href="https://actionrefund.com/category/uncategorized/">Uncategorized</a> (4)
</li>
						</ul>
					</div><!-- .widget -->

					<div class="widget widget_archive"><h2 class="widgettitle">Archives</h2><p>Try looking in the monthly archives. 🙂</p>		<label class="screen-reader-text" for="archives-dropdown--1">Archives</label>
		<select id="archives-dropdown--1" name="archive-dropdown">
			
			<option value="">Select Month</option>
				<option value='https://actionrefund.com/2022/09/'> September 2022 </option>
	<option value='https://actionrefund.com/2021/02/'> February 2021 </option>

		</select>

<script>
/* <![CDATA[ */
(function() {
	var dropdown = document.getElementById( "archives-dropdown--1" );
	function onSelectChange() {
		if ( dropdown.options[ dropdown.selectedIndex ].value !== '' ) {
			document.location.href = this.options[ this.selectedIndex ].value;
		}
	}
	dropdown.onchange = onSelectChange;
})();
/* ]]> */
</script>

		</div>
			</div><!-- .page-content -->
		</section><!-- .error-404 -->

	</main><!-- #main -->


<section class="l-contact-us background-gradient bg-waves">
<style>
	.l-contact-us__form .js-country-select{
		border: 1px solid hsla(0,0%,100%,.3);
		background: unset;
		width: 100%;
		padding: 15px 22px;
		font-size: 18px;
		color: #fff;
		transition: border-color .3s ease;
	}
	.js-country-select option{
		color:#000;
	}
	.l-contact-us__form .js-country-select:focus-visible{
		outline: unset;
	}
.form__label-grid {
   display: grid;
   grid-template-columns: 22px minmax(148px, 627px);
   grid-gap: 10px;
	align-items: center;
}
.form__checkbox-wrapper label {
   font-family: "Poppins-Regular", sans-serif;
   font-weight: 400;
   font-size: 18px;
   line-height: 160%;
   color: #fff;
   cursor: pointer;
}
.js-contact-form .form__checkbox-wrapper .form__chekbox-input {
   -webkit-animation: none;
   -moz-animation: none;
   appearance: none;
	-webkit-appearance: auto;
	height:unset;
	width:unset;
	width: 0;
    margin: 0;
}
.form__chekbox {
   position: absolute;
   background-color: transparent;
   border: 1px solid #BDBCBC;
   border-radius: 2px;
   width: 22px;
   height: 22px;
   cursor: pointer;
}
.form__checkbox-wrapper {
   margin-bottom: 30px;
}
.form__chekbox-input:checked+.form__chekbox {
   background-color: #27AE60;
   background-image: url(https://actionrefund.com/wp-content/uploads/2022/09/bird.svg);
   width: 22px;
   height: 22px;
   background-repeat: no-repeat;
   background-position-x: center;
   background-position-y: center;
   border-radius: 2px;
   border: none;
}
	.l-contact-us__form .select2-selection {
    height: 63px!important;
}
	</style>
  <div class="wrapper">
    <div class="l-columns-2">
      <div>
        <h2 class="l-contact-us__title">Got scammed online ?</h2>
        <p class="l-contact-us__text">Thanks to our past experience and panel of experts, backed by a database of known online scams, we are able to provide our services in order to help our customers retrieve their lost funds. We are here for each and everyone of you who have fallen victim to any sort of online scam. Our team is ready to track down your money, no matter how dire the situation may seem, and get you back what is rightfully yours.</p>
        <form id="contact-form" class="l-contact-us__form js-contact-form" method="post">
          <input type="hidden" name="sent_from" value=" - ">
			          
            
            <label class="half-width">
              <input type="text" placeholder="Name" name="name">
                          </label>

            
            
            
            <label class="half-width">
              <input type="email" placeholder="Mail" name="email">
                            <span class="error-message">The mail is invalid<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="10" cy="10" r="10" fill="#EB5757"></circle><path d="M8.97576 5.2H11.0478L10.6978 11.752H9.31176L8.97576 5.2ZM10.0118 15.098C9.68509 15.098 9.41442 14.9953 9.19976 14.79C8.98509 14.5753 8.87776 14.314 8.87776 14.006C8.87776 13.698 8.98509 13.4413 9.19976 13.236C9.41442 13.0307 9.68509 12.928 10.0118 12.928C10.3291 12.928 10.5904 13.0307 10.7958 13.236C11.0104 13.4413 11.1178 13.698 11.1178 14.006C11.1178 14.314 11.0104 14.5753 10.7958 14.79C10.5904 14.9953 10.3291 15.098 10.0118 15.098Z" fill="white"></path></svg> </span>
                          </label>

            
            
            
            <label class="select-input half-width">
              <select class="js-country-select" name="country_code">
                <option value="">Country code</option>
                <option value="">AF +93</option>
                <option value="">AX +358</option>
                <option value="">AL +355</option>
                <option value="">DZ +213</option>
                <option value="">AS +1684</option>
                <option value="">AD +376</option>
                <option value="">AO +244</option>
                <option value="">AI +1264</option>
                <option value="">AQ +672</option>
                <option value="">AG +1268</option>
                <option value="">AR +54</option>
                <option value="">AM +374</option>
                <option value="">AW +297</option>
                <option value="">AU +61</option>
                <option value="">AT +43</option>
                <option value="">AZ +994</option>
                <option value="">BS +1242</option>
                <option value="">BH +973</option>
                <option value="">BD +880</option>
                <option value="">BB +1246</option>
                <option value="">BY +375</option>
                <option value="">BE +32</option>
                <option value="">BZ +501</option>
                <option value="">BJ +229</option>
                <option value="">BM +1441</option>
                <option value="">BT +975</option>
                <option value="">BO +591</option>
                <option value="">BQ +5997</option>
                <option value="">BA +387</option>
                <option value="">BW +267</option>
                <option value="">IO +246</option>
                <option value="">VG +1284</option>
                <option value="">VI +1340</option>
                <option value="">BN +673</option>
                <option value="">BG +359</option>
                <option value="">BF +226</option>
                <option value="">BI +257</option>
                <option value="">KH +855</option>
                <option value="">CM +237</option>
                <option value="">CA +1</option>
                <option value="">CV +238</option>
                <option value="">KY +1345</option>
                <option value="">CF +236</option>
                <option value="">TD +235</option>
                <option value="">CL +56</option>
                <option value="">CN +86</option>
                <option value="">CX +61</option>
                <option value="">CC +61</option>
                <option value="">CO +57</option>
                <option value="">KM +269</option>
                <option value="">CG +242</option>
                <option value="">CD +243</option>
                <option value="">CK +682</option>
                <option value="">CR +506</option>
                <option value="">HR +385</option>
                <option value="">CU +53</option>
                <option value="">CW +599</option>
                <option value="">CY +357</option>
                <option value="">CZ+420</option>
                <option value="">DK +45</option>
                <option value="">DJ +253</option>
                <option value="">DM +1767</option>
                <option value="">DO +1809</option>
                <option value="">EC +593</option>
                <option value="">EG +20</option>
                <option value="">SV +503</option>
                <option value="">GQ +240</option>
                <option value="">ER +291</option>
                <option value="">EE +372</option>
                <option value="">ET +251</option>
                <option value="">FK +500</option>
                <option value="">FO +298</option>
                <option value="">FJ +679</option>
                <option value="">FI +358</option>
                <option value="">FR +33</option>
                <option value="">GF +594</option>
                <option value="">PF +689</option>
                <option value="">GA +241</option>
                <option value="">GM +220</option>
                <option value="">GE +995</option>
                <option value="">DE +49</option>
                <option value="">GH +233</option>
                <option value="">GI +350</option>
                <option value="">GR +30</option>
                <option value="">GL +299</option>
                <option value="">GD +1473</option>
                <option value="">GP +590</option>
                <option value="">GU +1671</option>
                <option value="">GT +502</option>
                <option value="">GG +44</option>
                <option value="">GN +224</option>
                <option value="">GW +245</option>
                <option value="">GY +592</option>
                <option value="">HT +509</option>
                <option value="">VA +379</option>
                <option value="">HN +504</option>
                <option value="">HK +852</option>
                <option value="">HU +36</option>
                <option value="">IS +354</option>
                <option value="">IN +91</option>
                <option value="">ID +62</option>
                <option value="">CI +225</option>
                <option value="">IR +98</option>
                <option value="">IQ +964</option>
                <option value="">IE +35</option>
                <option value="">IM +44</option>
                <option value="">IL +972</option>
                <option value="">IT +39</option>
                <option value="">JM +1876</option>
                <option value="">JP +81</option>
                <option value="">JE +44</option>
                <option value="">JO +962</option>
                <option value="">KZ +76</option>
                <option value="">KE +254</option>
                <option value="">KI +686</option>
                <option value="">KW +965</option>
                <option value="">KG +996</option>
                <option value="">LA +856</option>
                <option value="">LV +371</option>
                <option value="">LB +961</option>
                <option value="">LS +266</option>
                <option value="">LR +231</option>
                <option value="">LY +218</option>
                <option value="">LI +423</option>
                <option value="">LT +370</option>
                <option value="">LU +352</option>
                <option value="">MO +853</option>
                <option value="">MK +389</option>
                <option value="">MG +261</option>
                <option value="">MW +265</option>
                <option value="">MY +60</option>
                <option value="">MV +960</option>
                <option value="">ML +223</option>
                <option value="">MT +356</option>
                <option value="">MH +692</option>
                <option value="">MQ +596</option>
                <option value="">MR +222</option>
                <option value="">MU +230</option>
                <option value="">YT +262</option>
                <option value="">MX +52</option>
                <option value="">FM +691</option>
                <option value="">MD +373</option>
                <option value="">MC +377</option>
                <option value="">MN +976</option>
                <option value="">ME +382</option>
                <option value="">MS +1664</option>
                <option value="">MA +212</option>
                <option value="">MZ +258</option>
                <option value="">MM +95</option>
                <option value="">NA +264</option>
                <option value="">NR +674</option>
                <option value="">NP +977</option>
                <option value="">NL +31</option>
                <option value="">NC +687</option>
                <option value="">NZ +64</option>
                <option value="">NI +505</option>
                <option value="">NE +227</option>
                <option value="">NG +234</option>
                <option value="">NU +683</option>
                <option value="">NF +672</option>
                <option value="">KP +850</option>
                <option value="">MP +1670</option>
                <option value="">NO +47</option>
                <option value="">OM +968</option>
                <option value="">PK +92</option>
                <option value="">PW +680</option>
                <option value="">PS +970</option>
                <option value="">PA +507</option>
                <option value="">PG +675</option>
                <option value="">PY +595</option>
                <option value="">PE +51</option>
                <option value="">PH +63</option>
                <option value="">PN +64</option>
                <option value="">PL +48</option>
                <option value="">PT +351</option>
                <option value="">PR +1787</option>
                <option value="">QA +974</option>
                <option value="">XK +383</option>
                <option value="">RE +262</option>
                <option value="">RO +40</option>
                <option value="">RU +7</option>
                <option value="">RW +250</option>
                <option value="">SH +290</option>
                <option value="">KN +1869</option>
                <option value="">LC +1758</option>
                <option value="">MF +590</option>
                <option value="">PM +508</option>
                <option value="">VC +1784</option>
                <option value="">WS +685</option>
                <option value="">SM +378</option>
                <option value="">ST +239</option>
                <option value="">SA +966</option>
                <option value="">SN +221</option>
                <option value="">RS +381</option>
                <option value="">SC +248</option>
                <option value="">SL +232</option>
                <option value="">SG +65</option>
                <option value="">SX +1721</option>
                <option value="">SK +421</option>
                <option value="">SI +386</option>
                <option value="">SB +677</option>
                <option value="">SO +252</option>
                <option value="">ZA +27</option>
                <option value="">GS +500</option>
                <option value="">KR +82</option>
                <option value="">SS +211</option>
                <option value="">ES +34</option>
                <option value="">LK +94</option>
                <option value="">SD +249</option>
                <option value="">SR +597</option>
                <option value="">SJ +4779</option>
                <option value="">SZ +268</option>
                <option value="">SE +46</option>
                <option value="">CH +41</option>
                <option value="">SY +963</option>
                <option value="">TW +886</option>
                <option value="">TJ +992</option>
                <option value="">TZ +255</option>
                <option value="">TH +66</option>
                <option value="">TL +670</option>
                <option value="">TG +228</option>
                <option value="">TK +690</option>
                <option value="">TO +676</option>
                <option value="">TT +1868</option>
                <option value="">TN +216</option>
                <option value="">TR +90</option>
                <option value="">TR +90</option>
                <option value="">TC +1649</option>
                <option value="">TV +688</option>
                <option value="">UG +256</option>
                <option value="">UA +380</option>
                <option value="">AE +971</option>
                <option value="">GB +44</option>
                <option value="">US +1</option>
                <option value="">UY +598</option>
                <option value="">UZ +998</option>
                <option value="">VU +678</option>
                <option value="">VE +58</option>
                <option value="">VN +84</option>
                <option value="">WF +681</option>
                <option value="">EH +212</option>
                <option value="">YE +967</option>
                <option value="">ZM +260</option>
                <option value="">ZW +263</option>
              </select>
              <input type="tel" name="tel" placeholder="Phone">
				
            </label>

            
            
            
            <label class="half-width">
              <select name="deposit" class="js-nosearch-select">
                                <option value="Less than 5000$">Less than 5000$</option>
                                <option value="More than 5000$">More than 5000$</option>
                              </select>
            </label>

            
            
            
            <label>
              <textarea name="message" placeholder="Message"></textarea>
            </label>

            
                      			<input type="hidden" name="utm_source" id="utm_source">
			<input type="hidden" name="utm_medium" id="utm_medium">
			<input type="hidden" name="utm_campaign" id="utm_campaign">
			<input type="hidden" name="utm_term" id="utm_term">
			<input type="hidden" name="utm_content" id="utm_content">
			<div class="form__checkbox-wrapper">
				<label for="form__checkbox-label" class="form__label-grid"><input type="checkbox" checked name="check" id="form__checkbox-label" class="form__chekbox-input"><div class="form__chekbox"></div>I agree to receive emails from Action Refund.</label>
			</div>
          <label>
            <button class="btn" type="submit">Send</button>
          </label>

        </form>
      </div>
      <div class="l-contact-us__image">
        <img src="https://actionrefund.com/wp-content/themes/coelix/assets/images/svg/contact-form-image.svg" alt="action refund">
      </div>
    </div>
  </div>
</section>

<footer id="colophon" class="footer bg-waves background-gradient">
	<div class="wrapper">
		<div class="footer__inner">

			<!-- Contact -->
			<ul class="footer__contact">

				<li class="footer__col">
					<h6 class="footer__col-title">
						<div class="footer__col-title-wrap">
							<img src="https://actionrefund.com/wp-content/themes/coelix/assets/images/svg/email.svg" alt="action refund">
							<a target="_blank" href="/cdn-cgi/l/email-protection#b5c6c0c5c5dac7c1f5d4d6c1dcdadbc7d0d3c0dbd19bd6dad8">our email</a>
						</div>
						<span class="footer__col-link"><a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="94e7e1e4e4fbe6e0d4f5f7e0fdfbfae6f1f2e1faf0baf7fbf9">[email&#160;protected]</a></span>
					</h6>

					<h6 class="footer__col-title">
						<div class="footer__col-title-wrap">
							<img src="https://actionrefund.com/wp-content/themes/coelix/assets/images/svg/privacy-policy.svg" alt="action refund">
							<a target="_blank" href="https://actionrefund.com/privacy-policy">privacy policy</a>
						</div>
					</h6>
				</li>

				<li class="footer__col">
					<h6 class="footer__col-title">
						<div class="footer__col-title-wrap">
							<img src="https://actionrefund.com/wp-content/themes/coelix/assets/images/svg/map.svg" alt="action refund">
							<a href="https://www.google.com.ua/maps/search/Tuval St 19, Ramat Gan, Israel, 5252234">our address</a>
						</div>
						 <span class="footer__col-link">Abba Hillel Silver Rd 4, Ramat Gan, Israel, 5250607</span>
					</h6>


					<h6 class="footer__col-title">
						<div class="footer__col-title-wrap">
							<img src="https://actionrefund.com/wp-content/themes/coelix/assets/images/svg/docs.svg" alt="action refund">
							<a target="_blank" href="https://actionrefund.com/terms-and-conditions">terms and conditions</a>
						</div>
					</h6>
				</li>

				<li class="footer__col footer__col--phones">
					<h6 class="footer__col-title">
						<div class="footer__col-title-wrap">
							<img src="https://actionrefund.com/wp-content/themes/coelix/assets/images/svg/phone.svg" alt="action refund">
							<span>our phone</span>
						</div>
					</h6>
										<a target="_blank" class="footer__col-text" href="tel: +972 79-607-9198"><span>IL:</span>  +972 79-607-9198</a>
										<a target="_blank" class="footer__col-text" href="tel: +43 720-880098"><span>AT:</span>  +43 720-880098</a>
										<a target="_blank" class="footer__col-text" href="tel:+61 3-7003-9255"><span>AU:</span> +61 3-7003-9255</a>
										<a target="_blank" class="footer__col-text" href="tel:+1 647-360-8379"><span>CA:</span> +1 647-360-8379</a>
										<a target="_blank" class="footer__col-text" href="tel: +31 85-888-8294"><span>NL:</span>  +31 85-888-8294</a>
									</li>

			</ul>

			<!-- Disclaimer -->
			<div class="footer__disclaimer">
				<p class="footer__disclaimer-text">IMPORTANT NOTICE!
Please note that there are other websites using our company name and we would like to notify the community.
Action Refund LTD located in Ramat Gan HaYetsira 3 - 5252141 - Israel operates only through the domains www.actionrefund.com and lp.actionrefund.com.
				
<br> <br> Disclaimer: Action Refund offers free consultations. Chargebacks and other funds recovery programs subsequently contracted are subject to fees, charges and / or commissions depending on the history of each case and the type of service selected. Action Refund does not offer any investment or financial advice. For UK residents only, Action Refund does not assist consumers in making complaints about mis-sold investment products purchased from companies regulated by the Prudential Regulation Authority (PRA) and / or the UK Financial Conduct. Authority (FCA), such as contracts for difference.</p>
				
			</div>
			

			<!-- Bottom line -->
			<div class="footer__bottom">
				<ul class="footer__cards">
										<li class="footer__cards-item"><img src="https://actionrefund.com/wp-content/uploads/2020/11/visa_PNG2-7-1.png" alt="action refund"></li>
										<li class="footer__cards-item"><img src="https://actionrefund.com/wp-content/uploads/2020/11/visa_PNG2-7-2.png" alt="action refund"></li>
										<li class="footer__cards-item"><img src="https://actionrefund.com/wp-content/uploads/2020/11/visa_PNG2-7-3.png" alt="action refund"></li>
										<li class="footer__cards-item"><img src="https://actionrefund.com/wp-content/uploads/2020/11/visa_PNG2-7-4.png" alt="action refund"></li>
										<li class="footer__cards-item"><img src="https://actionrefund.com/wp-content/uploads/2020/11/gdpr-logo-2227777-1.png" alt="action refund"></li>
										<li class="footer__cards-item"><img src="https://actionrefund.com/wp-content/uploads/2020/11/image-5.png" alt="action refund"></li>
										<li class="footer__cards-item"><img src="https://actionrefund.com/wp-content/uploads/2020/11/image-6.png" alt="action refund"></li>
									</ul>

				<div class="footer__social">
										<a target="_blank" href="https://www.facebook.com/Action-Refund-LTD-105591984244275/"><img src="https://actionrefund.com/wp-content/uploads/2020/11/facebook.svg" alt="action refund"></a>
										<a target="_blank" href="https://twitter.com/LtdRefund"><img src="https://actionrefund.com/wp-content/uploads/2020/11/twitter.svg" alt="action refund"></a>
										<a target="_blank" href="https://www.instagram.com/actionrefund/?igshid=1vn6oecckogq3"><img src="https://actionrefund.com/wp-content/uploads/2020/12/instagram.svg" alt="action refund"></a>
									</div>

				<span class="footer__copyright">© 2020 – All Rights Reserved.</span>
			</div>
		</div>
	</div>
</footer>

<div id="contact-form-popup" class="popup">
	<style>
	.js-contact-form .js-country-select{
		border: 1px solid hsla(0,0%,100%,.3);
		background: unset;
		width: 100%;
		padding: 15px 22px;
		font-size: 18px;
		color: #fff;
		transition: border-color .3s ease;
	}
	.js-contact-form option{
		color:#000;
	}
	.js-contact-form .js-country-select:focus-visible{
		outline: unset;
	}
	.contact-modal .select2-selection {
    	height: 53px!important;
	}
		.form__label-grid {
   display: grid;
   grid-template-columns: 22px minmax(148px, 627px);
   grid-gap: 10px;
	align-items: center;
}
.form__checkbox-wrapper label {
   font-family: "Poppins-Regular", sans-serif;
   font-weight: 400;
   font-size: 18px;
   line-height: 160%;
   color: #fff;
   cursor: pointer;
}
.js-contact-form .form__checkbox-wrapper .form__chekbox-input {
   -webkit-animation: none;
   -moz-animation: none;
   appearance: none;
	-webkit-appearance: auto;
	height:unset;
	width:unset;
	width: 0;
    margin: 0;
}
.form__chekbox {
   position: absolute;
   background-color: transparent;
   border: 1px solid #BDBCBC;
   border-radius: 2px;
   width: 22px;
   height: 22px;
   cursor: pointer;
}
.form__checkbox-wrapper {
   margin-bottom: 30px;
}
.form__chekbox-input:checked+.form__chekbox {
   background-color: #27AE60;
   background-image: url(https://actionrefund.com/wp-content/uploads/2022/09/bird.svg);
   width: 22px;
   height: 22px;
   background-repeat: no-repeat;
   background-position-x: center;
   background-position-y: center;
   border-radius: 2px;
   border: none;
}
@media screen and (max-width: 768px){
	.contact-modal .select2-selection {
    	height: 43px!important;
	}
}
@media screen and (max-width: 575px){
	.contact-modal .select2-selection {
    	height: 33px!important;
	}
	.contact-modal .js-country-select{
		padding: 5px 22px;
	}
}
	</style>
	<div class="wrapper">
		<div class="popup__inner">

			<div data-modal class="contact-modal">
        <i class="contact-modal__close i-cross" data-modal-close></i>
        <div class="contact-modal__form">
          <h2 class="contact-modal__title">Have you been scammed online?</h2>
          <p class="contact-modal__subtitle">If you have any questions, the manager will contact you.</p>
          <form id="contact-popup-form" class="js-contact-form">
            <input type="hidden" name="sent_from" value="'' ">

            
              
              <label class="">
                <input type="text" placeholder="Name" name="name">
                              </label>

              
              
              
              <label class="">
                <input type="text" placeholder="Email" name="email">
                              </label>

              
              
              
              <label class="select-input ">
                <select class="js-country-select" name="country_code">
                  <option value="">Country code</option>
					<option value="">AF +93</option>
					<option value="">AX +358</option>
					<option value="">AL +355</option>
					<option value="">DZ +213</option>
					<option value="">AS +1684</option>
					<option value="">AD +376</option>
					<option value="">AO +244</option>
					<option value="">AI +1264</option>
					<option value="">AQ +672</option>
					<option value="">AG +1268</option>
					<option value="">AR +54</option>
					<option value="">AM +374</option>
					<option value="">AW +297</option>
					<option value="">AU +61</option>
					<option value="">AT +43</option>
					<option value="">AZ +994</option>
					<option value="">BS +1242</option>
					<option value="">BH +973</option>
					<option value="">BD +880</option>
					<option value="">BB +1246</option>
					<option value="">BY +375</option>
					<option value="">BE +32</option>
					<option value="">BZ +501</option>
					<option value="">BJ +229</option>
					<option value="">BM +1441</option>
					<option value="">BT +975</option>
					<option value="">BO +591</option>
					<option value="">BQ +5997</option>
					<option value="">BA +387</option>
					<option value="">BW +267</option>
					<option value="">IO +246</option>
					<option value="">VG +1284</option>
					<option value="">VI +1340</option>
					<option value="">BN +673</option>
					<option value="">BG +359</option>
					<option value="">BF +226</option>
					<option value="">BI +257</option>
					<option value="">KH +855</option>
					<option value="">CM +237</option>
					<option value="">CA +1</option>
					<option value="">CV +238</option>
					<option value="">KY +1345</option>
					<option value="">CF +236</option>
					<option value="">TD +235</option>
					<option value="">CL +56</option>
					<option value="">CN +86</option>
					<option value="">CX +61</option>
					<option value="">CC +61</option>
					<option value="">CO +57</option>
					<option value="">KM +269</option>
					<option value="">CG +242</option>
					<option value="">CD +243</option>
					<option value="">CK +682</option>
					<option value="">CR +506</option>
					<option value="">HR +385</option>
					<option value="">CU +53</option>
					<option value="">CW +599</option>
					<option value="">CY +357</option>
					<option value="">CZ+420</option>
					<option value="">DK +45</option>
					<option value="">DJ +253</option>
					<option value="">DM +1767</option>
					<option value="">DO +1809</option>
					<option value="">EC +593</option>
					<option value="">EG +20</option>
					<option value="">SV +503</option>
					<option value="">GQ +240</option>
					<option value="">ER +291</option>
					<option value="">EE +372</option>
					<option value="">ET +251</option>
					<option value="">FK +500</option>
					<option value="">FO +298</option>
					<option value="">FJ +679</option>
					<option value="">FI +358</option>
					<option value="">FR +33</option>
					<option value="">GF +594</option>
					<option value="">PF +689</option>
					<option value="">GA +241</option>
					<option value="">GM +220</option>
					<option value="">GE +995</option>
					<option value="">DE +49</option>
					<option value="">GH +233</option>
					<option value="">GI +350</option>
					<option value="">GR +30</option>
					<option value="">GL +299</option>
					<option value="">GD +1473</option>
					<option value="">GP +590</option>
					<option value="">GU +1671</option>
					<option value="">GT +502</option>
					<option value="">GG +44</option>
					<option value="">GN +224</option>
					<option value="">GW +245</option>
					<option value="">GY +592</option>
					<option value="">HT +509</option>
					<option value="">VA +379</option>
					<option value="">HN +504</option>
					<option value="">HK +852</option>
					<option value="">HU +36</option>
					<option value="">IS +354</option>
					<option value="">IN +91</option>
					<option value="">ID +62</option>
					<option value="">CI +225</option>
					<option value="">IR +98</option>
					<option value="">IQ +964</option>
					<option value="">IE +35</option>
					<option value="">IM +44</option>
					<option value="">IL +972</option>
					<option value="">IT +39</option>
					<option value="">JM +1876</option>
					<option value="">JP +81</option>
					<option value="">JE +44</option>
					<option value="">JO +962</option>
					<option value="">KZ +76</option>
					<option value="">KE +254</option>
					<option value="">KI +686</option>
					<option value="">KW +965</option>
					<option value="">KG +996</option>
					<option value="">LA +856</option>
					<option value="">LV +371</option>
					<option value="">LB +961</option>
					<option value="">LS +266</option>
					<option value="">LR +231</option>
					<option value="">LY +218</option>
					<option value="">LI +423</option>
					<option value="">LT +370</option>
					<option value="">LU +352</option>
					<option value="">MO +853</option>
					<option value="">MK +389</option>
					<option value="">MG +261</option>
					<option value="">MW +265</option>
					<option value="">MY +60</option>
					<option value="">MV +960</option>
					<option value="">ML +223</option>
					<option value="">MT +356</option>
					<option value="">MH +692</option>
					<option value="">MQ +596</option>
					<option value="">MR +222</option>
					<option value="">MU +230</option>
					<option value="">YT +262</option>
					<option value="">MX +52</option>
					<option value="">FM +691</option>
					<option value="">MD +373</option>
					<option value="">MC +377</option>
					<option value="">MN +976</option>
					<option value="">ME +382</option>
					<option value="">MS +1664</option>
					<option value="">MA +212</option>
					<option value="">MZ +258</option>
					<option value="">MM +95</option>
					<option value="">NA +264</option>
					<option value="">NR +674</option>
					<option value="">NP +977</option>
					<option value="">NL +31</option>
					<option value="">NC +687</option>
					<option value="">NZ +64</option>
					<option value="">NI +505</option>
					<option value="">NE +227</option>
					<option value="">NG +234</option>
					<option value="">NU +683</option>
					<option value="">NF +672</option>
					<option value="">KP +850</option>
					<option value="">MP +1670</option>
					<option value="">NO +47</option>
					<option value="">OM +968</option>
					<option value="">PK +92</option>
					<option value="">PW +680</option>
					<option value="">PS +970</option>
					<option value="">PA +507</option>
					<option value="">PG +675</option>
					<option value="">PY +595</option>
					<option value="">PE +51</option>
					<option value="">PH +63</option>
					<option value="">PN +64</option>
					<option value="">PL +48</option>
					<option value="">PT +351</option>
					<option value="">PR +1787</option>
					<option value="">QA +974</option>
					<option value="">XK +383</option>
					<option value="">RE +262</option>
					<option value="">RO +40</option>
					<option value="">RU +7</option>
					<option value="">RW +250</option>
					<option value="">SH +290</option>
					<option value="">KN +1869</option>
					<option value="">LC +1758</option>
					<option value="">MF +590</option>
					<option value="">PM +508</option>
					<option value="">VC +1784</option>
					<option value="">WS +685</option>
					<option value="">SM +378</option>
					<option value="">ST +239</option>
					<option value="">SA +966</option>
					<option value="">SN +221</option>
					<option value="">RS +381</option>
					<option value="">SC +248</option>
					<option value="">SL +232</option>
					<option value="">SG +65</option>
					<option value="">SX +1721</option>
					<option value="">SK +421</option>
					<option value="">SI +386</option>
					<option value="">SB +677</option>
					<option value="">SO +252</option>
					<option value="">ZA +27</option>
					<option value="">GS +500</option>
					<option value="">KR +82</option>
					<option value="">SS +211</option>
					<option value="">ES +34</option>
					<option value="">LK +94</option>
					<option value="">SD +249</option>
					<option value="">SR +597</option>
					<option value="">SJ +4779</option>
					<option value="">SZ +268</option>
					<option value="">SE +46</option>
					<option value="">CH +41</option>
					<option value="">SY +963</option>
					<option value="">TW +886</option>
					<option value="">TJ +992</option>
					<option value="">TZ +255</option>
					<option value="">TH +66</option>
					<option value="">TL +670</option>
					<option value="">TG +228</option>
					<option value="">TK +690</option>
					<option value="">TO +676</option>
					<option value="">TT +1868</option>
					<option value="">TN +216</option>
					<option value="">TR +90</option>
					<option value="">TR +90</option>
					<option value="">TC +1649</option>
					<option value="">TV +688</option>
					<option value="">UG +256</option>
					<option value="">UA +380</option>
					<option value="">AE +971</option>
					<option value="">GB +44</option>
					<option value="">US +1</option>
					<option value="">UY +598</option>
					<option value="">UZ +998</option>
					<option value="">VU +678</option>
					<option value="">VE +58</option>
					<option value="">VN +84</option>
					<option value="">WF +681</option>
					<option value="">EH +212</option>
					<option value="">YE +967</option>
					<option value="">ZM +260</option>
					<option value="">ZW +263</option>
                </select>
                <input type="tel" name="tel" placeholder="Tel">
              </label>

              
              
              
              <label class="">
                <select name="deposit_amount" class="js-nosearch-select">
                                    <option value="Over 5,000">Over 5,000</option>
                                    <option value="Less than 5,000">Less than 5,000</option>
                                  </select>
              </label>

              
              
              
              <label>
                <textarea name="message" placeholder="Message Description"></textarea>
              </label>
			  <div class="form__checkbox-wrapper">
				<label for="form__checkbox-label" class="form__label-grid"><input type="checkbox" checked name="check" id="form__checkbox-label" class="form__chekbox-input"><div class="form__chekbox"></div>I agree to receive emails from Action Refund.</label>
			</div>

              
                          			  <input type="hidden" name="utm_source" id="utm_source">
			  <input type="hidden" name="utm_medium" id="utm_medium">
			  <input type="hidden" name="utm_campaign" id="utm_campaign">
			  <input type="hidden" name="utm_term" id="utm_term">
			  <input type="hidden" name="utm_content" id="utm_content">
            <label><button class="btn" type="submit">Send</button></label>

          </form>
        </div>
        <div class="contact-modal__image"><img src="https://actionrefund.com/wp-content/themes/coelix/assets/images/svg/lose-money.svg" alt="action refund"></div>
			</div>

		</div>
	</div>
</div><div id="calculator-popup" class="popup">
	<style>
.calc-form__label-grid {
   display: grid;
   grid-template-columns: 22px minmax(148px, 627px);
   grid-gap: 10px;
	align-items: center;
}
.calc-form__checkbox-wrapper label {
   font-family: "Poppins-Regular", sans-serif;
   font-weight: 400;
   font-size: 18px;
   line-height: 160%;
   color: #fff;
   cursor: pointer;
}
.calc-form .calc-form__checkbox-wrapper .calc-form__chekbox-input {
   -webkit-animation: none;
   -moz-animation: none;
   appearance: none;
	-webkit-appearance: auto;
	height:unset;
	width:unset;
	width: 0;
    margin: 0;
}
.calc-form__chekbox {
   position: absolute;
   background-color: transparent;
   border: 1px solid #BDBCBC;
   border-radius: 2px;
   width: 22px;
   height: 22px;
   cursor: pointer;
}
.calc-form__chekbox-input:checked+.calc-form__chekbox {
   background-color: #27AE60;
   background-image: url(https://actionrefund.com/wp-content/uploads/2022/09/bird.svg);
   width: 22px;
   height: 22px;
   background-repeat: no-repeat;
   background-position-x: center;
   background-position-y: center;
   border-radius: 2px;
   border: none;
}
.calculator-modal label:not(:last-child), .calculator-modal .steps, .form__checkbox-wrapper{
	margin-bottom: 10px;
}
.calculator-modal p{
	margin-bottom: 10px;
	line-height: unset;
	font-size: 12px;
}
#calc-input__message{
	height:55px;
}
.calculator-modal__title{
	font-size:28px;
	margin-bottom: 5px;
}
.steps-item, .cacl-step.active-calc-step{
	font-size:18px;
}
.cacl-step:not(:last-child)::after{
	top: 12px;
	right: -80%;
}
.calculator-modal{
	max-width:1300px;
	padding: 120px 110px 100px;
}
.calculator-modal label{
	font-size: 16px;
	line-height: 120%;
}
.calculator-modal input:not([type="submit"]), .calculator-modal textarea, .calc-code, .calc-amount-input, .calc-currency-input{
	padding: 5px 15px;
}
.calc-code{
	min-height:unset;
}
.calculator-form .btn{
	font-size: 16px;
	padding: 12px 87px;
	line-height:unset;
}
.calculator-form .btn{
	margin-top:15px;
}
.calculator-form .form__chekbox-input{
	border: none;
}
.calculator-form .js-country-select{
	border: 1px solid hsla(0,0%,100%,.3);
	background: unset;
	width: 100%;
	padding: 15px 22px;
	font-size: 18px;
	color: #fff;
	transition: border-color .3s ease;
}
.js-country-select option{
	color:#000;
}
.calculator-form .js-country-select:focus-visible{
	outline: unset;
}
.calculator-form .select-input{
	height:23px;
}
.select2-selection{
	height:23px!important;
}
		
@media screen and (max-width: 40em){
	.calculator-form .js-country-select{
		padding: 5px 22px;
		font-size: 12px;
	}
	.calculator-form .select-input {
/* 		height: 23px; */
	}
	..calculator-modal input:not([type="submit"]), .calculator-modal textarea, .total-deposit, .calc-currency, .calc-code{
		font-size: 12px;
	}
	.calculator-modal label{
		font-size: 12px;
	}
	.calculator-form .btn {
		padding: 5px 47px;
	}
	.calculator-modal {
		padding: 80px 60px 100px;
	}
	.calculator-form .form__checkbox-wrapper label{
		font-size: 12px;
	}
	.calculator-modal p{
		font-size: 10px;
	}
	.select2-selection {
/* 		height: 23px!important; */
	}
}
		@media screen and (max-width: 575em){
			.calculator-form .js-country-select{
		padding: 5px 22px;
		font-size: 12px;
	}
	.calculator-modal input:not([type="submit"]), .calculator-modal textarea, .total-deposit, .calc-currency, .calc-code{
		font-size: 12px;
	}
	.calculator-modal label{
		font-size: 12px;
	}
	.calculator-form .btn {
		padding: 5px 47px;
	}
	.calculator-modal {
		padding: 80px 60px 100px;
	}
	.calculator-form .form__checkbox-wrapper label{
		font-size: 12px;
	}
	.calculator-modal p{
		font-size: 10px;
	}
	.l-contact-us__form .js-country-select{
		padding: 5px 22px;
	}
	.l-contact-us__form input:not([type=submit]), textarea{
		padding: 20px 22px;
	}
	.l-contact-us__form .select2-selection {
		height: 53px;
	}
	.select2-selection {
		height: 23px;
	}
	.calculator-form .select-input {
		height: 23px;
	}
}
	</style>
  <div class="wrapper">
    <div class="popup__inner">

      <div class="calculator-modal" data-modal>
        <i class="i-cross" data-modal-close></i>

        <div class="calculator-modal-screen is-active">
                    <h2 class="calculator-modal__title">Refund Calculator</h2>
          
          <ul class="steps">
                        <li class="steps-item is-active">Step 1</li>
                        <li class="steps-item ">Step 2</li>
                        <li class="steps-item ">Step 3</li>
                      </ul>

                    <p>A Refund Calculator is a user-friendly online tool, which helps you in calculating your refund amount based on your information</p>
          
          <!-- Steps -->
                    <form class="calculator-form calculator-form-1 is-active">
                        <input type="hidden" name="sent_from" value="Calculator form">
            
            
            
            <label>
              When was the first time deposit? ( year and month)              <input type="text" placeholder="" name="first_deposit">
                          </label>

            
            
            
            <label>
              When was the last time deposit? ( year and month)              <input type="text" placeholder="" name="last_deposit">
                          </label>

            
            			
			  
            <label>
                            <button class="btn" type="submit">Next</button>
            </label>
          </form>
                    <form class="calculator-form calculator-form-2">
            
            
            
            <label>
              Total deposit amount              <select name="deposit_amount" class="js-nosearch-select">
                                <option value="Less than 5k">Less than 5k</option>
                                <option value="More than 5k">More than 5k</option>
                              </select>
            </label>

            
            
            
            <label>
              Currency              <select class="js-nosearch-select" name="currency">
                <option value="usd">USD</option>
                <option value="cad">CAD</option>
                <option value="aud">AUD</option>
                <option value="eur">EUR</option>
              </select>
            </label>

            
            
            
            <label>
              Which company deposit?              <input type="text" placeholder="" name="deposit">
                          </label>

            
            			
			  
            <label>
                            <button class="btn" type="submit">Next</button>
            </label>
          </form>
                    <form class="calculator-form calculator-form-3">
            
            
            
            <label>
              Full Name              <input type="text" placeholder="Full Name" name="name">
                          </label>

            
            
            
            <label>
              Email              <input type="email" placeholder="Email" name="email">
                            <span class="error-message">The mail is invalid<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="10" cy="10" r="10" fill="#EB5757"></circle><path d="M8.97576 5.2H11.0478L10.6978 11.752H9.31176L8.97576 5.2ZM10.0118 15.098C9.68509 15.098 9.41442 14.9953 9.19976 14.79C8.98509 14.5753 8.87776 14.314 8.87776 14.006C8.87776 13.698 8.98509 13.4413 9.19976 13.236C9.41442 13.0307 9.68509 12.928 10.0118 12.928C10.3291 12.928 10.5904 13.0307 10.7958 13.236C11.0104 13.4413 11.1178 13.698 11.1178 14.006C11.1178 14.314 11.0104 14.5753 10.7958 14.79C10.5904 14.9953 10.3291 15.098 10.0118 15.098Z" fill="white"></path></svg> </span>
                          </label>

            
            
            
            <label>
              Phone Number              <div class="select-input">
                <select class="js-country-select" name="country_code">
                  <option value="">Country code</option>
					<option value="">AF +93</option>
					<option value="">AX +358</option>
					<option value="">AL +355</option>
					<option value="">DZ +213</option>
					<option value="">AS +1684</option>
					<option value="">AD +376</option>
					<option value="">AO +244</option>
					<option value="">AI +1264</option>
					<option value="">AQ +672</option>
					<option value="">AG +1268</option>
					<option value="">AR +54</option>
					<option value="">AM +374</option>
					<option value="">AW +297</option>
					<option value="">AU +61</option>
					<option value="">AT +43</option>
					<option value="">AZ +994</option>
					<option value="">BS +1242</option>
					<option value="">BH +973</option>
					<option value="">BD +880</option>
					<option value="">BB +1246</option>
					<option value="">BY +375</option>
					<option value="">BE +32</option>
					<option value="">BZ +501</option>
					<option value="">BJ +229</option>
					<option value="">BM +1441</option>
					<option value="">BT +975</option>
					<option value="">BO +591</option>
					<option value="">BQ +5997</option>
					<option value="">BA +387</option>
					<option value="">BW +267</option>
					<option value="">IO +246</option>
					<option value="">VG +1284</option>
					<option value="">VI +1340</option>
					<option value="">BN +673</option>
					<option value="">BG +359</option>
					<option value="">BF +226</option>
					<option value="">BI +257</option>
					<option value="">KH +855</option>
					<option value="">CM +237</option>
					<option value="">CA +1</option>
					<option value="">CV +238</option>
					<option value="">KY +1345</option>
					<option value="">CF +236</option>
					<option value="">TD +235</option>
					<option value="">CL +56</option>
					<option value="">CN +86</option>
					<option value="">CX +61</option>
					<option value="">CC +61</option>
					<option value="">CO +57</option>
					<option value="">KM +269</option>
					<option value="">CG +242</option>
					<option value="">CD +243</option>
					<option value="">CK +682</option>
					<option value="">CR +506</option>
					<option value="">HR +385</option>
					<option value="">CU +53</option>
					<option value="">CW +599</option>
					<option value="">CY +357</option>
					<option value="">CZ+420</option>
					<option value="">DK +45</option>
					<option value="">DJ +253</option>
					<option value="">DM +1767</option>
					<option value="">DO +1809</option>
					<option value="">EC +593</option>
					<option value="">EG +20</option>
					<option value="">SV +503</option>
					<option value="">GQ +240</option>
					<option value="">ER +291</option>
					<option value="">EE +372</option>
					<option value="">ET +251</option>
					<option value="">FK +500</option>
					<option value="">FO +298</option>
					<option value="">FJ +679</option>
					<option value="">FI +358</option>
					<option value="">FR +33</option>
					<option value="">GF +594</option>
					<option value="">PF +689</option>
					<option value="">GA +241</option>
					<option value="">GM +220</option>
					<option value="">GE +995</option>
					<option value="">DE +49</option>
					<option value="">GH +233</option>
					<option value="">GI +350</option>
					<option value="">GR +30</option>
					<option value="">GL +299</option>
					<option value="">GD +1473</option>
					<option value="">GP +590</option>
					<option value="">GU +1671</option>
					<option value="">GT +502</option>
					<option value="">GG +44</option>
					<option value="">GN +224</option>
					<option value="">GW +245</option>
					<option value="">GY +592</option>
					<option value="">HT +509</option>
					<option value="">VA +379</option>
					<option value="">HN +504</option>
					<option value="">HK +852</option>
					<option value="">HU +36</option>
					<option value="">IS +354</option>
					<option value="">IN +91</option>
					<option value="">ID +62</option>
					<option value="">CI +225</option>
					<option value="">IR +98</option>
					<option value="">IQ +964</option>
					<option value="">IE +35</option>
					<option value="">IM +44</option>
					<option value="">IL +972</option>
					<option value="">IT +39</option>
					<option value="">JM +1876</option>
					<option value="">JP +81</option>
					<option value="">JE +44</option>
					<option value="">JO +962</option>
					<option value="">KZ +76</option>
					<option value="">KE +254</option>
					<option value="">KI +686</option>
					<option value="">KW +965</option>
					<option value="">KG +996</option>
					<option value="">LA +856</option>
					<option value="">LV +371</option>
					<option value="">LB +961</option>
					<option value="">LS +266</option>
					<option value="">LR +231</option>
					<option value="">LY +218</option>
					<option value="">LI +423</option>
					<option value="">LT +370</option>
					<option value="">LU +352</option>
					<option value="">MO +853</option>
					<option value="">MK +389</option>
					<option value="">MG +261</option>
					<option value="">MW +265</option>
					<option value="">MY +60</option>
					<option value="">MV +960</option>
					<option value="">ML +223</option>
					<option value="">MT +356</option>
					<option value="">MH +692</option>
					<option value="">MQ +596</option>
					<option value="">MR +222</option>
					<option value="">MU +230</option>
					<option value="">YT +262</option>
					<option value="">MX +52</option>
					<option value="">FM +691</option>
					<option value="">MD +373</option>
					<option value="">MC +377</option>
					<option value="">MN +976</option>
					<option value="">ME +382</option>
					<option value="">MS +1664</option>
					<option value="">MA +212</option>
					<option value="">MZ +258</option>
					<option value="">MM +95</option>
					<option value="">NA +264</option>
					<option value="">NR +674</option>
					<option value="">NP +977</option>
					<option value="">NL +31</option>
					<option value="">NC +687</option>
					<option value="">NZ +64</option>
					<option value="">NI +505</option>
					<option value="">NE +227</option>
					<option value="">NG +234</option>
					<option value="">NU +683</option>
					<option value="">NF +672</option>
					<option value="">KP +850</option>
					<option value="">MP +1670</option>
					<option value="">NO +47</option>
					<option value="">OM +968</option>
					<option value="">PK +92</option>
					<option value="">PW +680</option>
					<option value="">PS +970</option>
					<option value="">PA +507</option>
					<option value="">PG +675</option>
					<option value="">PY +595</option>
					<option value="">PE +51</option>
					<option value="">PH +63</option>
					<option value="">PN +64</option>
					<option value="">PL +48</option>
					<option value="">PT +351</option>
					<option value="">PR +1787</option>
					<option value="">QA +974</option>
					<option value="">XK +383</option>
					<option value="">RE +262</option>
					<option value="">RO +40</option>
					<option value="">RU +7</option>
					<option value="">RW +250</option>
					<option value="">SH +290</option>
					<option value="">KN +1869</option>
					<option value="">LC +1758</option>
					<option value="">MF +590</option>
					<option value="">PM +508</option>
					<option value="">VC +1784</option>
					<option value="">WS +685</option>
					<option value="">SM +378</option>
					<option value="">ST +239</option>
					<option value="">SA +966</option>
					<option value="">SN +221</option>
					<option value="">RS +381</option>
					<option value="">SC +248</option>
					<option value="">SL +232</option>
					<option value="">SG +65</option>
					<option value="">SX +1721</option>
					<option value="">SK +421</option>
					<option value="">SI +386</option>
					<option value="">SB +677</option>
					<option value="">SO +252</option>
					<option value="">ZA +27</option>
					<option value="">GS +500</option>
					<option value="">KR +82</option>
					<option value="">SS +211</option>
					<option value="">ES +34</option>
					<option value="">LK +94</option>
					<option value="">SD +249</option>
					<option value="">SR +597</option>
					<option value="">SJ +4779</option>
					<option value="">SZ +268</option>
					<option value="">SE +46</option>
					<option value="">CH +41</option>
					<option value="">SY +963</option>
					<option value="">TW +886</option>
					<option value="">TJ +992</option>
					<option value="">TZ +255</option>
					<option value="">TH +66</option>
					<option value="">TL +670</option>
					<option value="">TG +228</option>
					<option value="">TK +690</option>
					<option value="">TO +676</option>
					<option value="">TT +1868</option>
					<option value="">TN +216</option>
					<option value="">TR +90</option>
					<option value="">TR +90</option>
					<option value="">TC +1649</option>
					<option value="">TV +688</option>
					<option value="">UG +256</option>
					<option value="">UA +380</option>
					<option value="">AE +971</option>
					<option value="">GB +44</option>
					<option value="">US +1</option>
					<option value="">UY +598</option>
					<option value="">UZ +998</option>
					<option value="">VU +678</option>
					<option value="">VE +58</option>
					<option value="">VN +84</option>
					<option value="">WF +681</option>
					<option value="">EH +212</option>
					<option value="">YE +967</option>
					<option value="">ZM +260</option>
					<option value="">ZW +263</option>
                </select>
                <input type="tel" name="phone" placeholder="Phone Number">
              </div>
            </label>

            
            
            
            <label>
              Message              <textarea name="message" placeholder="Message"></textarea>
            </label>
			  <div class="calc-form__checkbox-wrapper">
				  <label for="calc-form__checkbox-label" class="calc-form__label-grid"><input type="checkbox" checked name="check" id="calc-form__checkbox-label" class="calc-form__chekbox-input"><div class="calc-form__chekbox"></div>I agree to receive emails from Action Refund.</label>
			  </div>

            
            			
			  
            <label>
                            <button class="btn" type="submit">Send</button>
            </label>
          </form>
                  </div>

        <div class="calculator-modal-screen calculator-modal-screen--loading">
          <h2 class="calculator-modal__title">Loading</h2>
          <div class="loader"></div>
        </div>

        <div class="calculator-modal-screen calculator-modal-screen--thanks">
          <h2 class="calculator-modal__title">Your data was received to the system</h2>
          <p>( we are analyzing your data)</p>
          <a href="#" class="btn js-remove-calc-icon" data-modal-close>Thank you!</a>
        </div>

      </div>

    </div>
  </div>
</div><!-- Contact form -->
<div class="js-thanks-popup-contact popup">
	<div class="wrapper">
		<div class="popup__inner">

			<div data-modal class="popup-thanks-modal">
				<i data-modal-close class="i-cross"></i>
				<h2 class="popup-thanks-modal__title">Thank you!</h2>
				<p class="popup-thanks-modal__subtitle">Our manager will contact you soon</p>
				<img class="popup-thanks-modal__image" src="https://actionrefund.com/wp-content/themes/coelix/assets/images/svg/popup-image.svg" alt="action refund">
				<button data-modal-close class="btn">Great</button>
			</div>

		</div>
	</div>
</div>

<!-- Popup contact form -->
<div class="js-thanks-popup-contact-popup popup">
	<div class="wrapper">
		<div class="popup__inner">

			<div data-modal class="popup-thanks-modal">
				<i data-modal-close class="i-cross"></i>
				<h2 class="popup-thanks-modal__title">Thank you!</h2>
				<p class="popup-thanks-modal__subtitle">Our manager will contact you soon</p>
				<img class="popup-thanks-modal__image" src="https://actionrefund.com/wp-content/themes/coelix/assets/images/svg/popup-image.svg" alt="action refund">
				<button data-modal-close class="btn">Great</button>
			</div>

		</div>
	</div>
</div>

<!-- Calculator -->
<div class="js-thanks-popup-calculator popup">
	<div class="wrapper">
		<div class="popup__inner">

			<div data-modal class="popup-thanks-modal">
				<i data-modal-close class="i-cross"></i>
				<h2 class="popup-thanks-modal__title">Thank you!</h2>
				<p class="popup-thanks-modal__subtitle">Our manager will contact you soon</p>
				<img class="popup-thanks-modal__image" src="https://actionrefund.com/wp-content/themes/coelix/assets/images/svg/popup-image.svg" alt="action refund">
				<button data-modal-close class="btn">Great</button>
			</div>

		</div>
	</div>
</div>
<a href="#" class="calculator-icon is-hidden" id="js-calculator-trigger">
	<div class="calculator-icon-inner">
		<div class="calculator-icon__side calculator-icon__side--front"><img src="https://actionrefund.com/wp-content/themes/coelix/assets/images/svg/calc-icon.svg" alt="action refund"></div>
		<div class="calculator-icon__side calculator-icon__side--back">Refund calculator</div>
	</div>
</a>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script defer src='https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js'></script>
<script defer src='https://widget.trustpilot.com/bootstrap/v5/tp.widget.bootstrap.min.js'></script>
<script defer src='https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js'></script>
<script defer src='https://actionrefund.com/wp-content/themes/coelix/dist/lazyembed.min.js?ver=1664539757'></script>
<script>
var wp = {"ajaxurl":"https:\/\/actionrefund.com\/wp-admin\/admin-ajax.php","is_rtl":"","integromat_url":"https:\/\/hook.integromat.com\/0z7ph11ye6v6acgmnmwnv4s396dbwg2w"};
</script>
<script defer src='https://actionrefund.com/wp-content/themes/coelix/dist/app.min.js?ver=1664539757'></script>
<script defer src='https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js?ver=5.4.12'></script>
<script defer src='https://actionrefund.com/wp-content/themes/coelix/dist/mar.js?ver=1664539757'></script>
<script defer src='https://actionrefund.com/wp-includes/js/wp-embed.min.js?ver=5.4.12'></script>

</body>
</html>

<!-- Page generated by LiteSpeed Cache 5.2.1 on 2022-10-20 14:22:21 -->